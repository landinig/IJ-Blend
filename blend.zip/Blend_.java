import ij.*;
import ij.plugin.*;
import ij.gui.*;
import ij.process.*;

/*
Blend, by G.Landini@bham.ac.uk
10/11/2003 for ImageJ

Blends two greyscale or 2 RGB images
Based on Calculator_Plus by Wayne Rasband (wayne@codon.nih.gov)

v1.0 10/11/2003 release
v1.1 17/06/2005 blending RGB
*/

public class Blend_ implements PlugIn {

	static String title = "Blend";
    static boolean createWindow = true, whiteparticles = false;
	int[] wList;
	private String[] titles;
	int i1Index;
	int i2Index;
	ImagePlus i1;
	ImagePlus i2;
	boolean replicate;
	protected int percentage;

	public void run(String arg) {
		if (IJ.versionLessThan("1.31l"))
			return;
		wList = WindowManager.getIDList();
		if (wList==null || wList.length<2) {
			IJ.showMessage(title, "There must be at least two windows open");
			return;
		}
		titles = new String[wList.length];
		for (int i=0; i<wList.length; i++) {
			ImagePlus imp = WindowManager.getImage(wList[i]);
			if (imp!=null)
				titles[i] = imp.getTitle();
			else
				titles[i] = "";
		}

		if (!showDialog())
			return;


		//if ((i1.getWidth()!=i2.getWidth()) && (i1.getHeight()!=i2.getHeight()))
		//	{IJ.showMessage(title, "Images must be the same size"); return;}

		long start = System.currentTimeMillis();
		boolean calibrated = i1.getCalibration().calibrated() || i2.getCalibration().calibrated();

		if (calibrated)
			createWindow = true;
		if (createWindow) {
			if (replicate)
				i2 = replicateImage(i2, calibrated, i1.getStackSize());
			else
				i2 = duplicateImage(i2, calibrated);
			if (i2==null)
				{IJ.showMessage(title, "Out of memory"); return;}
			i2.show();
		}
		blend(i1, i2);
		IJ.showStatus(IJ.d2s((System.currentTimeMillis()-start)/1000.0, 2)+" seconds");
	}

	public boolean showDialog() {
		GenericDialog gd = new GenericDialog(title);
		gd.addMessage("Blend v 1.1");
		gd.addMessage("Differently sized images are aligned\nto the upper left corner and preserve\nthe size of Image2.");

		gd.addChoice("Image1:", titles, titles[0]);
		gd.addChoice("Image2:", titles, titles[1]);
		gd.addNumericField("% of Image1 (0 - 100)", 50, 0);
		gd.addCheckbox("Create New Window", createWindow);
		gd.showDialog();
		if (gd.wasCanceled())
			return false;
		int i1Index = gd.getNextChoiceIndex();
		int i2Index = gd.getNextChoiceIndex();
		percentage = (int) gd.getNextNumber();
		createWindow = gd.getNextBoolean();
		i1 = WindowManager.getImage(wList[i1Index]);
		i2 = WindowManager.getImage(wList[i2Index]);
		int d1 = i1.getStackSize();
		int d2 = i2.getStackSize();
		if (d2==1 && d1>1) {
			createWindow = true;
			replicate = true;
		}
		return true;
 }

	public void blend(ImagePlus i1, ImagePlus i2) {
		double v1, v2, red, green,blue;
		int width;//  = i1.getWidth();
		int height;// = i1.getHeight();
		ImageProcessor ip1, ip2;
		int slices1 = i1.getStackSize();
		int slices2 = i2.getStackSize();
		float[] ctable1 = i1.getCalibration().getCTable();
		float[] ctable2 = i2.getCalibration().getCTable();
		ImageStack stack1 = i1.getStack();
		ImageStack stack2 = i2.getStack();
		int currentSlice = i2.getCurrentSlice();
		ImageStatistics stats;
		int x,y, p1, p2;

		if(i1.getWidth()> i2.getWidth())
			width=i2.getWidth();
		else
			width=i1.getWidth();

		if(i1.getHeight()> i2.getHeight())
			height=i2.getHeight();
		else
			height=i1.getHeight();

		if (i1.getBitDepth() != i2.getBitDepth()){
				if (i2.getTitle().equals("Blended")) i2.hide();
				IJ.showMessage("Error", "Only Greyscale and RGB images are supported. \nTo blend RGB and Greyscale, convert the greyscale to RGB.");
		}

		IJ.showStatus("Blend...");
		for (int n=1; n<=slices2; n++) {
			ip1 = stack1.getProcessor(n<=slices1?n:slices1);
			//stats=i1.getStatistics();
			//stats=i2.getStatistics();

			ip2 = stack2.getProcessor(n);
			ip1.setCalibrationTable(ctable1);
			ip2.setCalibrationTable(ctable2);

			if (i1.getBitDepth()==8 && i2.getBitDepth()==8){
				for(y=0;y<height;y++) {
					for(x=0;x<width;x++)
							ip2.putPixel(x,y,(int)((percentage*ip1.getPixel(x,y)+(100-percentage)*ip2.getPixel(x,y))/100));
				}
			}
			else if (i1.getBitDepth()==24 && i2.getBitDepth()==24){
				for(y=0;y<height;y++) {
					for(x=0;x<width;x++){
						p1=ip1.getPixel(x,y);
						p2=ip2.getPixel(x,y);
						red=(double)((percentage * ((p1 & 0xff0000) >> 16 )+ (100-percentage)* ((p2 & 0xff0000) >> 16 ))/100);
						green=(double)((percentage * ((p1 & 0x00ff00) >> 8 )+ (100-percentage)* ((p2 & 0x00ff00) >> 8 ))/100);
						blue=(double)((percentage * ((p1 & 0x0000ff)  )+ (100-percentage)* ((p2 & 0x0000ff) ))/100);
						ip2.putPixel(x,y, (((int)red & 0xff) <<16)+ (((int)green & 0xff) << 8) + ((int)blue & 0xff));
					}
				}
			}

			if (n==currentSlice) {
				i2.getProcessor().resetMinAndMax();
				i2.updateAndDraw();
			}

			IJ.showProgress((double)n/slices2);
			IJ.showStatus(n+"/"+slices2);
		}
	}



	ImagePlus duplicateImage(ImagePlus img1, boolean calibrated) {
		ImageStack stack1 = img1.getStack();
		int width = stack1.getWidth();
		int height = stack1.getHeight();
		int n = stack1.getSize();
		ImageStack stack2 = img1.createEmptyStack();
		float[] ctable = img1.getCalibration().getCTable();
		try {
			for (int i=1; i<=n; i++) {
				ImageProcessor ip1 = stack1.getProcessor(i);
				ImageProcessor ip2 = ip1.duplicate();
				if (calibrated) {
					ip2.setCalibrationTable(ctable);
					ip2 = ip2.convertToFloat();
				}
				stack2.addSlice(stack1.getSliceLabel(i), ip2);
			}
		}
		catch(OutOfMemoryError e) {
			stack2.trim();
			stack2 = null;
			return null;
		}
		ImagePlus img2 =  new ImagePlus("Blended", stack2);
		return img2;
	}

	ImagePlus replicateImage(ImagePlus img1, boolean calibrated, int n) {
		ImageProcessor ip1 = img1.getProcessor();
		int width = ip1.getWidth();
		int height = ip1.getHeight();
		ImageStack stack2 = img1.createEmptyStack();
		float[] ctable = img1.getCalibration().getCTable();
		try {
			for (int i=1; i<=n; i++) {
				ImageProcessor ip2 = ip1.duplicate();
				if (calibrated) {
					ip2.setCalibrationTable(ctable);
					ip2 = ip2.convertToFloat();
				}
				stack2.addSlice(null, ip2);
			}
		}
		catch(OutOfMemoryError e) {
			stack2.trim();
			stack2 = null;
			return null;
		}
		ImagePlus img2 =  new ImagePlus("Blended", stack2);
		return img2;
	}

}

